//题号：912
class Solution {
    //选择排序
    public List<Integer> sortArray(int[] nums) {

        for(int i=0;i<nums.length;i++){
            int index = i;
            for(int j=i+1;j<nums.length;j++){
                if (nums[j] < nums[index]) {
                    index = j;                      //交换位置
                }
            }
            int tmp = nums[index];//交换元素
            nums[index] = nums[i];
            nums[i] = tmp;
        }
        ArrayList<Integer> list = new ArrayList<>();
        for (int i = 0;i < nums.length;i++){
            list.add(nums[i]);
        }
        return list;
    }
}