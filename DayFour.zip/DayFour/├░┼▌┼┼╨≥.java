//题号：912
class Solution {
    public List<Integer> sortArray(int[] nums) {
        int mid=0;
        for(int i=0;i<nums.length-1;i++){
            for(int j=0;j<nums.length-i-1;j++){
                if(nums[j+1]<nums[j]){
                    mid=nums[j];
                    nums[j]=nums[j+1];
                    nums[j+1]=mid;
                }
            }
        }
        ArrayList<Integer> list = new ArrayList<>();
        for (int i = 0;i < nums.length;i++){
            list.add(nums[i]);
        }
        return list;
    }
}
