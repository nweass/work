题号：#122
class Solution {
    public int maxProfit(int[] prices) {
        int Profit = 0;
        for (int i=0; i<prices.length-1;i++) {
            int sale = prices[i + 1] - prices[i];       //相邻两天有利润即买卖股票
            if (sale > 0) {
                Profit += sale;
            }
        }
        return Profit;
    }
}