//题号：912
class Solution {
    public List<Integer> sortArray(int[] nums) {
        //模仿快速排序模板
        QuickSort(nums, 0, nums.length - 1);
        List<Integer> res = new ArrayList<Integer>();
        for (int i = 0; i < nums.length; i++){
            res.add(nums[i]);
        }
        return res;
    }
    public void QuickSort(int[] arr, int start, int end){
        if (start > end){
            return;
        }
        int mid = arr[start];
        int i = start;
        int j = end;
        while (i < j){
            while (i < j && arr[j] > mid){
                j--;
            }
            arr[i] = arr[j];
            i++;
            while(i < j && arr[i] < mid){
                i++;
            }
            arr[j] = arr[i];
            j--;
        }
        arr[i] = mid;
        QuickSort(arr, start, i - 1);
        QuickSort(arr,j + 1, end);
    }
}
