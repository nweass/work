/**
 * Definition for a binary tree node.
 * public class TreeNode {
 *     int val;
 *     TreeNode left;
 *     TreeNode right;
 *     TreeNode(int x) { val = x; }
 * }
 */
//题号；678
class Solution {
    // 看了题解后模仿
    int ans;
    public int longestUnivaluePath(TreeNode root) {
        ans = 0;
        text(root);
        return ans;
    }
    public int text(TreeNode node) {
        if (node == null) {                                 //要先判断是否为空
            return 0;
        }
        int left/*左叉*/ = text(node.left);          //递归核心，不断调用自身函数
        int right/*右叉*/ = text(node.right);            //不断测试各个节点
        int Left = 0, Right = 0;                                    //计数变量
        if (node.left != null && node.left.val == node.val) {
            Left += left + 1;                    //节点非空和节点值相同最好一起判断
        }
        if (node.right != null && node.right.val == node.val) {
            Right += right + 1;
        }
        ans = Math.max(ans, Left + Right);          //
        return Math.max(Left, Right);
    }
}
